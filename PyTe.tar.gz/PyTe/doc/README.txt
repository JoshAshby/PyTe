====================About============================
PyTe
Joshua Ashby
2008
I hold no responsibility for anything that may happen to your 
computer if you use this program or any program written in it.
By Using PyTe you agree to the terms of use, gpl, gnu license, and
the Python, and Qt License's
All Trademarks Subject to their owners
===================================================
Python License
===================================================
Qt Licence
===================================================
GPL
===================================================