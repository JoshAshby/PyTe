import sys
import os

__Dir = os.path.dirname(sys.argv[0])

_pkg_config = {
    'Dir'             : __Dir,
    'Pix'          : os.path.join(__Dir, 'pix'),
    'Icon'         : os.path.join(__Dir, 'icon'),
    'Doc'          : os.path.join(__Dir, 'doc'),
    'Examples'     : os.path.join(__Dir, 'examples'),
    'Others'           : __Dir,
    'bindir'              : __Dir,
    'mdir'                : __Dir,
    
    'qtui'                : True,
    'qttable'             : True,
    'qtcanvas'            : True,
}

def getConfig(name):
    try:
        return _pkg_config[name]
    except KeyError:
        pass

    raise AttributeError, '"%s" is not a valid configuration value' % name
