import os.path
from qt import *
from config import getConfig



class SplashScreen(QVBox):
    def __init__(self):
        QVBox.__init__(self, None, "splash", 
            Qt.WDestructiveClose | Qt.WStyle_Customize | Qt.WStyle_NoBorder |\
            Qt.WX11BypassWM | Qt.WStyle_StaysOnTop)
        self.setFrameStyle(QFrame.Plain)
        PyTe = QPixmap(os.path.join(getConfig('Pix'), 'PyTe.png'))
        pic = QLabel(self, "splashpic")
        pic.setPixmap(PyTe)
        self.msg = QLabel(self)
        self.msg.setIndent(6)
        self.msg.setPaletteBackgroundColor(Qt.black)
        self.msg.setPaletteForegroundColor(Qt.white)
        self.msg.setFrameStyle(QFrame.Plain)
        self.adjustSize()
        screen = QApplication.desktop().screenGeometry()
        self.move(QPoint(screen.center().x() - self.width()/2, 
                         screen.center().y() - self.height()/2))
        self.show()
        qApp.processEvents()
        
    def message(self, msg):

        self.msg.setText(msg)
        qApp.processEvents()

class NoneSplashScreen:

    def __init__(self):

        pass
        
    def message(self, msg):

        pass
